/*!
* Bootstrap v3.3.1 (http://getbootstrap.com)
* Copyright 2011-2014 Twitter, Inc.
* Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
*/$(".btnsearshh").click(function(){$(".barsearsh.clear").fadeOut()});$(".btnsearshh").click(function(){$(".barsearsh.clear").fadeIn();});